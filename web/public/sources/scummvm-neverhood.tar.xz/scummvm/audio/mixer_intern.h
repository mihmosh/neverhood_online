/* ScummVM - Graphic Adventure Engine
 *
 * ScummVM is the legal property of its developers, whose names
 * are too numerous to list here. Please refer to the COPYRIGHT
 * file distributed with this source distribution.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

#ifndef AUDIO_MIXER_INTERN_H
#define AUDIO_MIXER_INTERN_H

#include "common/scummsys.h"
#include "common/mutex.h"
#include "audio/mixer.h"

namespace Audio {

/**
 * @defgroup audio_mixer_intern Mixer implementation
 * @ingroup audio
 *
 * @brief The (default) implementation of the ScummVM audio mixing subsystem.
 * @{
 */

/**
 * The (default) implementation of the ScummVM audio mixing subsystem.
 *
 * Backends are responsible for allocating (and later releasing) an instance
 * of this class, which engines can access via OSystem::getMixer().
 *
 * Initialisation of instances of this class usually happens as follows:
 * 1) Creat a new Audio::MixerImpl instance.
 * 2) Set the hardware output sample rate via the setSampleRate() method.
 * 3) Hook up the mixCallback() in a suitable audio processing thread/callback.
 * 4) Change the mixer into ready mode via setReady(true).
 * 5) Start audio processing (e.g. by resuming the audio thread, if applicable).
 *
 * In the future, we might make it possible for backends to provide
 * (partial) alternative implementations of the mixer, e.g. to make
 * better use of native sound mixing support on low-end devices.
 *
 * @see OSystem::getMixer()
 */
class MixerImpl : public Mixer {
private:
	enum {
		NUM_CHANNELS = 32
	};

	Common::Mutex _mutex;

	const uint _sampleRate;
	const bool _stereo;
	uint _outBufSize;
	const uint _outBytesPerSample;
	const bool _clamp;
	bool _mixerReady;
	uint32 _handleSeed;

	struct SoundTypeSettings {
		SoundTypeSettings() : mute(false), volume(kMaxMixerVolume) {}

		bool mute;
		int volume;
	};

	SoundTypeSettings _soundTypeSettings[4];
	Channel *_channels[NUM_CHANNELS];


public:

	MixerImpl(uint sampleRate, bool stereo = true, uint outBufSize = 0, uint outBytesPerSample = 2, bool clamp = true);
	~MixerImpl();

	bool isReady() const override { Common::StackLock lock(_mutex); return _mixerReady; }

	Common::Mutex &mutex() override { return _mutex; }

	void playStream(
		SoundType type,
		SoundHandle *handle,
		AudioStream *input,
		int id, byte volume, int8 balance,
		DisposeAfterUse::Flag autofreeStream,
		bool permanent,
		bool reverseStereo) override;

	void stopAll() override;
	void stopID(int id) override;
	void stopHandle(SoundHandle handle) override;

	void pauseAll(bool paused) override;
	void pauseID(int id, bool paused) override;
	void pauseHandle(SoundHandle handle, bool paused) override;

	bool isSoundIDActive(int id) const override;
	int getSoundID(SoundHandle handle) const override;

	bool isSoundHandleActive(SoundHandle handle) const override;

	void muteSoundType(SoundType type, bool mute) override;
	bool isSoundTypeMuted(SoundType type) const override;

	void setChannelVolume(SoundHandle handle, byte volume) override;
	byte getChannelVolume(SoundHandle handle) const override;
	void setChannelBalance(SoundHandle handle, int8 balance) override;
	int8 getChannelBalance(SoundHandle handle) const override;
	void setChannelFaderL(SoundHandle handle, uint8 scaleL) override;
	uint8 getChannelFaderL(SoundHandle handle) const override;
	void setChannelFaderR(SoundHandle handle, uint8 scaleR) override;
	uint8 getChannelFaderR(SoundHandle handle) const override;
	void setChannelRate(SoundHandle handle, uint32 rate) override;
	uint32 getChannelRate(SoundHandle handle) const override;
	void resetChannelRate(SoundHandle handle) override;

	uint32 getSoundElapsedTime(SoundHandle handle) const override;
	Timestamp getElapsedTime(SoundHandle handle) const override;

	void loopChannel(SoundHandle handle) override;

	bool hasActiveChannelOfType(SoundType type) const override;

	void setVolumeForSoundType(SoundType type, int volume) override;
	int getVolumeForSoundType(SoundType type) const override;

	uint getOutputRate() const override;
	bool getOutputStereo() const override;
	uint getOutputBufSize() const override;
	uint getOutputBytesPerSample() const override;
	bool getClamping() const override;

protected:
	void insertChannel(SoundHandle *handle, Channel *chan);

public:
	/**
	 * Adjust the output buffer size
	 */
	void setOutputBufSize(uint outBufSize) { _outBufSize = outBufSize; }

	/**
	 * The mixer callback function, to be called at regular intervals by
	 * the backend (e.g. from an audio mixing thread). All the actual mixing
	 * work is done from here.
	 *
	 * @param samples Sample buffer, in which stereo 16-bit samples will be stored.
	 * @param len Length of the provided buffer to fill (in bytes, should be divisible by 4).
	 * @return number of sample pairs processed (which can still be silence!)
	 */
	int mixCallback(byte *samples, uint len);

	/**
	 * Set the internal 'is ready' flag of the mixer.
	 * Backends should invoke Mixer::setReady(true) once initialisation of
	 * their audio system has been completed.
	 */
	void setReady(bool ready);
};

/** @} */
} // End of namespace Audio

#endif
