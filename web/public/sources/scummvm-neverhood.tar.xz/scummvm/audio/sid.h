/* ScummVM - Graphic Adventure Engine
 *
 * ScummVM is the legal property of its developers, whose names
 * are too numerous to list here. Please refer to the COPYRIGHT
 * file distributed with this source distribution.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

#ifndef AUDIO_SID_H
#define AUDIO_SID_H

#include "audio/chip.h"

namespace Common {
class String;
}

namespace SID {

class SID;

class Config {
public:
	enum SidType {
		kSidPAL,
		kSidNTSC
	};

	/**
	 * Creates a SID driver.
	 */
	static SID *create(SidType type);

	static SidType parseSidType(const Common::String &str);
};

class SID : virtual public Audio::Chip {
private:
	static bool _hasInstance;

public:
	SID();
	virtual ~SID();

	/**
	 * Initializes the SID emulator.
	 *
	 * @return		true on success, false on failure
	 */
	virtual bool init() = 0;

	/**
	 * Reinitializes the SID emulator
	 */
	virtual void reset() = 0;

	/**
	 * Function to directly write to a specific SID register.
	 *
	 * @param r		hardware register number to write to
	 * @param v		value, which will be written
	 */
	virtual void writeReg(int r, int v) = 0;
};

} // End of namespace SID

#endif
